<?php

namespace Netflie\WhatsAppCloudApi\Message\Error;

final class InvalidMessage extends \Exception
{
}
